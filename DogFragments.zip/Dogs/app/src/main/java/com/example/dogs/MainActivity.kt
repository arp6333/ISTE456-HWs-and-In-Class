package com.example.dogs

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (supportFragmentManager.findFragmentById(R.id.content) == null) {
            supportFragmentManager.beginTransaction()
                .add(R.id.content, FirstFragment())
                .commit()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_info -> InfoDialog().show(supportFragmentManager, "info")
        }
        return super.onOptionsItemSelected(item)
    }

    fun displayDog(view: View) {
        val fragment = DisplayFragment()
        val args = Bundle()
        when (view.id) {
            R.id.dog_1 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.german_shepherd)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Medium to large-sized working dog that originated in Germany.")
            }
            R.id.dog_2 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.bulldog)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Medium sized, muscular, and hefty with a wrinkled face and a distinctive pushed-in nose.")
            }
            R.id.dog_3 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.poodle)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Comes in three varieties: Standard Poodle, Miniature Poodle, and Toy Poodle.")
            }
            R.id.dog_4 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.labrador_retriever)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Medium-large breed of retriever-gun dog that is the most popular dog in many countries.")
            }
            R.id.dog_5 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.beagle)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Scent hound, developed primarily for hunting hare.")
            }
            R.id.dog_6 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.dachshund)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Short-legged, long-bodied, and hound-type dog breed.")
            }
            R.id.dog_7 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.chihuahua)
                args.putString(DisplayFragment.ARG_TEXT_ID, "The smallest breed of dog and named after the Mexican state of Chihuahua.")
            }
            R.id.dog_8 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.husky)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Thickly furred double coat, erect triangular ears, and distinctive markings.")
            }
            R.id.dog_9 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.rottweiler)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Named \"butchers' dogs\", because their main use was to herd livestock and pull carts laden with butchered meat to market.")
            }
            R.id.dog_10 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.corgi)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Cattle herding dog breed that originated in Pembrokeshire, Wales.")
            }
            R.id.dog_11 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.shiba_inu)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Small-to-medium breed, smallest of the six original and distinct spitz breeds of dog native to Japan.")
            }
            R.id.dog_12 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.great_dane)
                args.putString(DisplayFragment.ARG_TEXT_ID, "German breed of domestic dog known for its large size.")
            }
            R.id.dog_13 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.doberman)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Has a long muzzle, stands on its pads, and is not usually heavy-footed.")
            }
            R.id.dog_14 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.pomeranian)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Spitz type that is named for the Pomerania region in north-west Poland and north-east Germany in Central Europe.")
            }
            R.id.dog_15 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.shih_tzu)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Toy dog breed, weighing from 4 to 7.25 kilograms when fully grown, developed in Tibet.")
            }
            R.id.dog_16 -> {
                args.putInt(DisplayFragment.ARG_IMAGE_ID, R.drawable.greyhound)
                args.putString(DisplayFragment.ARG_TEXT_ID, "Sighthound which has been bred for coursing game and greyhound racing.")
            }
        }
        fragment.arguments = args
        supportFragmentManager.beginTransaction()
            .replace(R.id.content, fragment)
            .commit()
    }
}