package com.example.tipcalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.PersistableBundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.SeekBar
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.NumberFormatException

class MainActivity : AppCompatActivity() {

    // variables used when saving/restoring state
    private var currentBillTotal = 0.00 // bill amount entered by the user
    private var currentCustomPercent = 0 // tip percent set with the seek bar

    // there are no 'static' variables, we use companion objects which are equivalent
    // every class can inherit a companion object
    companion object {
        // constants used when saving/restoring state
        private val BILL_TOTAL = "BILL_TOTAL"
        private val CUSTOM_PERCENT = "CUSTOM_PERCENT"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // check if the app was just started or is being restored from memory
        if (savedInstanceState == null) { // null means app just started running
            // initialize the current bill total and current custom percent
            currentBillTotal = 0.00
            currentCustomPercent = 18
        }
        else { // app is being restored from memory
            // set the current bill total and current custom percent to the saved amount
            currentBillTotal = savedInstanceState.getDouble(BILL_TOTAL)
            currentCustomPercent = savedInstanceState.getInt(CUSTOM_PERCENT)
        }

        // billTotalEditTextWatcher handles billTotalEditText's onTextChangedEvent
        billTotalEditText.addTextChangedListener(billTotalEditTextWatcher)

        // get the seek bar value when it changes
        customSeekBar.setOnSeekBarChangeListener(customSeekBarListener)
    }

    // updates the 10, 15, and 20 percent editTexts
    private fun updateStandard() {
        // use val because these are constant values
        // calculate the bill total with a 10% tip
        val tenPercentTip = currentBillTotal * 0.1
        val tenPercentTotal = currentBillTotal + tenPercentTip
        // update the GUI
        tipTenEditText.setText(String.format("%.02f", tenPercentTip))
        totalTenEditText.setText(String.format("%.02f", tenPercentTotal))

        // calculate the bill total with a 15% tip
        val fifteenPercentTip = currentBillTotal * 0.15
        val fifteenPercentTotal = currentBillTotal + fifteenPercentTip
        // update the GUI
        tipFifteenEditText.setText(String.format("%.02f", fifteenPercentTip))
        totalFifteenEditText.setText(String.format("%.02f", fifteenPercentTotal))

        // calculate the bill total with a 20% tip
        val twentyPercentTip = currentBillTotal * 0.2
        val twentyPercentTotal = currentBillTotal + twentyPercentTip
        // update the GUI
        tipTwentyEditText.setText(String.format("%.02f", twentyPercentTip))
        totalTwentyEditText.setText(String.format("%.02f", twentyPercentTotal))
    }

    // calculate the custom tip and total editTexts
    private fun updateCustom() {
        // set customTipTextView's text to match the position of the seek bar
        // we can ignore this warning for this
        customPercentTextView.text = currentCustomPercent.toString() + "%"

        // calculate the custom tip amount
        val customTipAmount = currentBillTotal * currentCustomPercent.toDouble() * .01 // (or divide by 100)

        // calculate the bill total including custom tip
        val customTotalAmount = currentBillTotal + customTipAmount

        // update the GUI
        tipEditText.setText(String.format("%.02f", customTipAmount))
        totalEditText.setText(String.format("%.02f", customTotalAmount))
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        // save values of billEditText and customSeekBar
        outState.putDouble(BILL_TOTAL, currentBillTotal)
        outState.putInt(CUSTOM_PERCENT, currentCustomPercent)
    }

    // called when the user changes the position of the seek bar
    // this is an anonymous class; 'object' throws an error so click it and auto implement all members to solve error
    private val customSeekBarListener = object: SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            // update the current custom percent then call updateCustom to update the GUI
            currentCustomPercent = progress // returns the integer in range 0-100 from seek bar
            updateCustom()
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {
            // ignore, we're not using
        }

        override fun onStopTrackingTouch(seekBar: SeekBar?) {
            // ignore, we're not using
        }
    }

    // this is an anonymous class; 'object' throws an error so click it and auto implement all members to solve error
    private val billTotalEditTextWatcher = object: TextWatcher {
        override fun beforeTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
            // ignore, we're not using
        }

        override fun onTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
            // convert the totalEditText text into a Double because it comes in as a String
            try {
                currentBillTotal = text.toString().toDouble()
            }
            catch (e: NumberFormatException) {
                currentBillTotal = 0.00 // default if exception occurs
            }

            // update the GUI
            updateStandard()
            updateCustom()
        }

        override fun afterTextChanged(editable: Editable?) {
            // ignore, we're not using
        }
    }
}
