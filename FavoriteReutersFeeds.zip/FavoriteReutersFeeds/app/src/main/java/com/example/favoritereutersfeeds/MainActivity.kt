package com.example.favoritereutersfeeds

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private lateinit var savedFeeds: SharedPreferences

    // anything done in onCreate must be done in less than 5 seconds
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // getSharedPreferences will read preferences saved in the "feeds" file, private makes it only accessible to this app
        savedFeeds = this.getSharedPreferences("feeds", Context.MODE_PRIVATE)

        saveButton.setOnClickListener { handleSaveButtonClick() }
        clearTagsButton.setOnClickListener { handleClearTagsButtonClick() }

        refreshButtons(null) // add the previously saved feeds to the GUI
    }

    private fun refreshButtons(newTag: String?) {
        // store saved tags into an array
        val tags: Array<String> = savedFeeds.all.keys.toTypedArray()
        // sort by tag
        tags.sortWith(String.CASE_INSENSITIVE_ORDER)

        // if a new tag was added, insert it into the GUI at the appropriate spot
        if (newTag != null) {
            var index = tags.indexOf(newTag)
            makeTagGUI(newTag, index)
        }
        // display all tags
        else {
            for (index in tags.indices) {
                makeTagGUI(tags[index], index)
            }
        }
    }

    // add a new search to the save file and refresh all the buttons
    private fun makeTag(query: String, tag: String) {
        val originalQuery = savedFeeds.getString(tag, "") // "" if it cannot find the tag

        // we have to check if EDIT is clicked or NEW is clicked to replace tag or add new tag
        val editor = savedFeeds.edit()
        editor.putString(tag, query)
        editor.apply() // updates the file
        // or do this to do it in one line
        //savedFeeds.edit().putString(tag, query).apply()

        // if new query, add it to the GUI
        if (originalQuery.equals("")) {
            refreshButtons(tag)
        }
    }

    private fun makeTagGUI(tag: String, index: Int) {
        // get LayoutInflater Service
        val inflater: LayoutInflater = LayoutInflater.from(applicationContext)

        // inflate the row
        val newTagView: View = inflater.inflate(R.layout.new_tag_view, null, false)

        val newTagButton = newTagView.findViewById<Button>(R.id.newTagButton)
        newTagButton.text = tag
        newTagButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                handleQueryButtonClick(v as Button)
            }
        })

        val newEditButton = newTagView.findViewById<Button>(R.id.newEditButton)
        newEditButton.setText(R.string.edit)
        newEditButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                handleEditButtonClick(v as Button)
            }
        })

        // add to the linear layout
        queryLinearLayout.addView(newTagView, index)
    }

    private fun clearButtons() {
        queryLinearLayout.removeAllViews()
    }

    private fun handleSaveButtonClick() {
        if (queryEditText.text.isNotEmpty() && tagEditText.text.isNotEmpty()) {
            makeTag(queryEditText.text.toString(), tagEditText.text.toString())
            queryEditText.setText("")
            tagEditText.setText("")

            // hide the soft keyboard
            (getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
                tagEditText.windowToken, 0
            )
        }
        else {
            // display error message
            val builder = AlertDialog.Builder(this@MainActivity)
            builder.setTitle(R.string.missingTitle)
            builder.setPositiveButton(R.string.OK, null) // null to not do anything when they click ok, just dismiss alert
            builder.setMessage(R.string.missingMessage)
            builder.create().show()
        }
    }
}
