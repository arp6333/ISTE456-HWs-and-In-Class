package com.example.apihomework

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ListView
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_main.*

private const val ARG_PARAM = "param1"

class MainFragment : Fragment() {

    private var imageURL: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            imageURL = it.getString(ARG_PARAM)
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        return inflater.inflate(R.layout.fragment_main, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        Picasso.get().load(imageURL).into(imageView)
    }

    companion object {
        @JvmStatic
        fun newInstance(imageURL: String) = MainFragment().apply {
            arguments = Bundle().apply {
                putString(ARG_PARAM, imageURL)
            }
        }
    }
}