package com.example.apihomework

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Html
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.FragmentManager
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import org.json.JSONObject
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private val apiURL = "https://random.dog/woof.json"
    private var okHttpClient: OkHttpClient = OkHttpClient()
    private var mainFragment: MainFragment? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button.setOnClickListener { loadRandomDog() }
    }

    private fun loadRandomDog() {
        if (isNetworkConnected()) {
            runOnUiThread {
                progressBar.visibility = View.VISIBLE
            }

            val request: Request = Request.Builder().url(apiURL)
                    .addHeader("Accept", "application/json")
                    .build()

            okHttpClient.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) { }

                override fun onResponse(call: Call, response: Response) {
                    val json = response?.body?.string()
                    val txt = (JSONObject(json).get("url")).toString()

                    runOnUiThread {
                        var url = ""
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            url = android.text.Html.fromHtml(txt, Html.FROM_HTML_MODE_LEGACY).toString()
                        }
                        else {
                            url = Html.fromHtml(txt).toString()
                        }

                        // API sometimes gives videos so we need to get a new one if so
                        if (url.contains(".mp4")) {
                            loadRandomDog()
                        }
                        else {
                            progressBar.visibility = View.GONE
                            mainFragment = MainFragment.newInstance(url)
                            supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
                            supportFragmentManager.beginTransaction().replace(R.id.theInfo, mainFragment!!).commit()
                        }
                    }
                }
            })
        }
        else {
            AlertDialog.Builder(this)
                    .setTitle("No internet connection")
                    .setMessage("Please check your internet connection and try again")
                    .setPositiveButton(android.R.string.ok) { _,_ -> }
                    .setIcon(android.R.drawable.ic_dialog_alert)
                    .show()
        }
    }

    private fun isNetworkConnected(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nw = connectivityManager.activeNetwork ?: return false
            val actNw = connectivityManager.getNetworkCapabilities(nw) ?: return false
            return when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        }
        else {
            val nwInfo = connectivityManager.activeNetworkInfo ?: return false
            return nwInfo.isConnected
        }
    }
}
