package com.example.favoritefeedsfragment

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import kotlinx.android.synthetic.main.fragment_feeds.*

class FeedsFragment : Fragment() {

    private lateinit var savedFeeds: SharedPreferences
    private var oldTag: String = ""

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_feeds, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // getSharedPreferences will read preferences saved in the "feeds" file, private makes it only accessible to this app
        savedFeeds = activity!!.getSharedPreferences("feeds", Context.MODE_PRIVATE)

        saveButton.setOnClickListener { handleSaveButtonClick() }
        clearTagsButton.setOnClickListener { handleClearTagsButtonClick() }

        refreshButtons(null) // add the previously saved feeds to the GUI
    }

    private fun refreshButtons(newTag: String?) {
        // store saved tags into an array
        val tags: Array<String> = savedFeeds.all.keys.toTypedArray()
        // sort by tag
        tags.sortWith(String.CASE_INSENSITIVE_ORDER)

        // if a new tag was added, insert it into the GUI at the appropriate spot
        if (newTag != null) {
            var index = tags.indexOf(newTag)
            makeTagGUI(newTag, index)
        }
        // display all tags
        else {
            for (index in tags.indices) {
                makeTagGUI(tags[index], index)
            }
        }
    }

    // add a new search to the save file and refresh all the buttons
    private fun makeTag(query: String, tag: String) {
        val originalQuery = savedFeeds.getString(tag, "") // empty string if it cannot find the tag

        // we have to check if EDIT is clicked to replace tag instead of adding a new tag
        val editor = savedFeeds.edit()
        if (oldTag != tag && oldTag != "") {
            // remove from the linear layout
            val tags: Array<String> = savedFeeds.all.keys.toTypedArray()
            tags.sortWith(String.CASE_INSENSITIVE_ORDER)
            var index = tags.indexOf(oldTag)
            queryLinearLayout.removeViewAt(index)
            // remove from savedFeeds
            editor.remove(oldTag)
        }
        editor.putString(tag, query)
        editor.apply() // updates the file

        // if new query, add it to the GUI
        if (originalQuery.equals("")) {
            refreshButtons(tag)
        }
    }

    private fun makeTagGUI(tag: String, index: Int) {
        // get LayoutInflater Service
        val inflater: LayoutInflater = activity!!.layoutInflater

        // inflate the row
        val newTagView: View = inflater.inflate(R.layout.new_tag_view, null, false)

        val newTagButton = newTagView.findViewById<Button>(R.id.newTagButton)
        newTagButton.text = tag
        newTagButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                handleQueryButtonClick(v as Button)
            }
        })

        val newEditButton = newTagView.findViewById<Button>(R.id.newEditButton)
        newEditButton.setText(R.string.edit)
        newEditButton.setOnClickListener(object: View.OnClickListener {
            override fun onClick(v: View?) {
                handleEditButtonClick(v as Button)
            }
        })

        // add to the linear layout
        queryLinearLayout.addView(newTagView, index)
    }

    private fun clearButtons() {
        queryLinearLayout.removeAllViews()
    }

    private fun handleSaveButtonClick() {
        if (queryEditText.text.isNotEmpty() && tagEditText.text.isNotEmpty()) {
            makeTag(queryEditText.text.toString(), tagEditText.text.toString())
            queryEditText.setText("")
            tagEditText.setText("")

            // hide the soft keyboard
            (activity!!.getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(
                tagEditText.windowToken, 0
            )
        }
        else {
            // display error message
            val builder = AlertDialog.Builder(activity)
            builder.setTitle(R.string.missingTitle)
            builder.setPositiveButton(R.string.OK, null) // null listener to not do anything when they click ok, just dismiss alert
            builder.setMessage(R.string.missingMessage)
            builder.create().show()
        }
        oldTag = "";
    }

    // handle clear tags button
    private fun handleClearTagsButtonClick() {
        // create a new AlertDialog builder (alert to make sure they really want to do it)
        var builder = AlertDialog.Builder(activity)
        builder.setTitle(R.string.confirmTitle)

        // provide OK button that dismisses the dialog and clear the tags
        builder.setPositiveButton(R.string.erase) {
            // listener
                dialog, which ->
            clearButtons()
            savedFeeds.edit().clear().apply()
        }

        builder.setCancelable(true)
        builder.setNegativeButton(R.string.cancel, null) // null listener to not do anything when they click ok, just dismiss alert

        builder.setMessage(R.string.confirmMessage)

        builder.create().show()
    }

    // implicit intent: we don't specify which component to display a web page - system will launch most appropriate activity based on data
    // if multiple activities can handle it, the system will display dialog so user can select one
    // if system cannot find one, system throws error (usually we would handle that error but don't need to for this)
    private fun handleQueryButtonClick(button: Button) {
        // load the selected search in a web browser
        // get the query
        val buttonText = button.text.toString()
        val query = savedFeeds.getString(buttonText, "")

        // create the URL
        val urlString = getString(R.string.searchURL) + query

        // create the intent to launch the web browser
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(urlString))

        // start the activity - basically executing the intent
        startActivity(webIntent)
    }

    // handle the edit button on click
    private fun handleEditButtonClick(button: Button) {
        // get all necessary GUI components first
        val buttonRow = button.parent as ConstraintLayout
        val searchButton = buttonRow.findViewById<Button>(R.id.newTagButton)
        val tag = searchButton.text.toString()
        oldTag = tag;

        // set the editTexts to match the chosen tag and query
        tagEditText.setText(tag)
        queryEditText.setText(savedFeeds.getString(tag, "")) // empty string default value
    }
}