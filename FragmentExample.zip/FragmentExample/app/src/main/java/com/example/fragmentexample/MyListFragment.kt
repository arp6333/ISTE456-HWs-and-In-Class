package com.example.fragmentexample

import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import androidx.fragment.app.ListFragment

class MyListFragment: ListFragment() {

    val itemsArrayList = arrayListOf<String>("A", "B", "C", "D", "E", "F", "G", "H", "I", "J")
    var itemChangedListener: ItemChangedListener? = null

    interface ItemChangedListener {
        fun onSelectedItemChanged(itemNameString: String)
    }

    fun setMyItemChangedListener(listener: ItemChangedListener) {
        itemChangedListener = listener
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        listAdapter = ItemArrayAdapter(this.context!!, R.layout.list_item, itemsArrayList)

        // Choice Mode Single = can only pick one item at a time
        listView.choiceMode = ListView.CHOICE_MODE_SINGLE
        listView.setBackgroundColor(Color.WHITE)
        listView.onItemClickListener = itemsOnItemClickListener
    }

    // custom array adapter
    inner class ItemArrayAdapter(context: Context, resource: Int, list: ArrayList<String>)
        : ArrayAdapter<String>(context, resource, list) {

        var resource: Int
        var list: ArrayList<String>
        var vi: LayoutInflater

        init {
            this.resource = resource
            this.list = list
            this.vi = context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        }

        // get the list view item for the given position
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            var holder: ViewHolder // current item's GUI
            var retView: View // what we're returning

            // if convertView is null, we need to inflate a new one and create our ViewHolder
            // otherwise, we will use the existing one
            if (convertView == null) {
                retView = vi.inflate(resource, null)

                holder = ViewHolder()
                holder.itemTextView = retView.findViewById<TextView>(R.id.text1)

                retView.tag = holder
            }
            else {
                // get the ViewHolder from convertView's tag
                holder = convertView.tag as ViewHolder
                retView = convertView
            }

            val item = list[position] // get current item
            holder.itemTextView?.text = item

            return retView
        }
    }

    internal class ViewHolder {
        var itemTextView: TextView? = null
    }

    private val itemsOnItemClickListener: AdapterView.OnItemClickListener =
        AdapterView.OnItemClickListener { adapterView, view, position, id ->
            itemChangedListener?.onSelectedItemChanged(
                (view as TextView).text.toString()
            )
        }
}