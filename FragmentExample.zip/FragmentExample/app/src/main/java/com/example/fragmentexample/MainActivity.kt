package com.example.fragmentexample

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.FragmentManager
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    private var myListFragment: MyListFragment? = null
    private var fragmentTwo: FragmentTwo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // set listeners for our buttons
        listButton.setOnClickListener {
            loadFragment("List")
        }

        fragmentTwoButton.setOnClickListener {
            loadFragment("Two")
        }

        // would need to keep track of which fragment is being displayed for device rotation if desired
        // for now, we will just do list
        loadFragment("List")
    }

    private fun loadFragment(which: String) {
        if (which == "List") {
            myListFragment = MyListFragment() // might want to check if null first in case we already have an existing list fragment
            myListFragment?.setMyItemChangedListener(itemChangedListener)

            // no transition or back stack (def - a stack of actions when back button is clicked) - but clear back stack
            supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
            supportFragmentManager.beginTransaction().replace(R.id.theInfo, myListFragment!!).commit()
        }
        else if (which == "Two") {
            fragmentTwo = FragmentTwo() // might want to check if null first in case we already have an existing fragment two

            // no transition or back stack (def - a stack of actions when back button is clicked) - but clear back stack
            supportFragmentManager.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
            supportFragmentManager.beginTransaction().replace(R.id.theInfo, fragmentTwo!!).commit()
        }
    }

    private var itemChangedListener: MyListFragment.ItemChangedListener =
        object: MyListFragment.ItemChangedListener {
            override fun onSelectedItemChanged(itemNameString: String) {
                // create and show the detail fragment
                var details = DetailFragment.newInstance(itemNameString)
                supportFragmentManager.beginTransaction().setCustomAnimations(
                    R.animator.fragment_animation_fade_in,
                    R.animator.fragment_animation_fade_out
                ).replace(R.id.theInfo, details).addToBackStack(null).commit()
            }
        }

}
