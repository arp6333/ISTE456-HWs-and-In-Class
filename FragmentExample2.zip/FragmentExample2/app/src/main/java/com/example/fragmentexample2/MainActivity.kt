package com.example.fragmentexample2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), FragmentOne.OnFragmentOneInteractionListener, FragmentTwo.OnFragmentTwoInteractionListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (savedInstanceState == null) {
            val frag1 = FragmentOne.newInstance("String 1", "String 2")
            val frag2 = FragmentTwo.newInstance("String 1", "String 2")

            // Both fragments added to manager with frag2 detached and frag1 attached
            supportFragmentManager
                .beginTransaction()
                .add(R.id.the_info, frag2, "frag2")
                .detach(frag2).
                add(R.id.the_info, frag1, "frag1")
                .commit()
        }

        button.setOnClickListener {
            val frag1 = supportFragmentManager.findFragmentByTag("frag1") as FragmentOne
            val frag2 = supportFragmentManager.findFragmentByTag("frag2") as FragmentTwo

            val ft = supportFragmentManager.beginTransaction()
            // If frag2 is detached, detach frag1 and attach frag2
            if (frag2.isDetached) {
                ft.detach(frag1).attach(frag2)
            }
            // If frag1 is detached, detach frag2 and attach frag1
            else if (frag1.isDetached) {
                ft.detach(frag2).attach(frag1)
            }
            ft.commit()
        }
    }

    override fun onFragmentOneInteraction(v: View) {
        Toast.makeText(applicationContext, "Hello from Fragment One", Toast.LENGTH_LONG).show()
    }

    override fun onFragmentTwoInteraction(v: View) {
        Toast.makeText(applicationContext, "Hello from Fragment Two", Toast.LENGTH_LONG).show()
    }
}
