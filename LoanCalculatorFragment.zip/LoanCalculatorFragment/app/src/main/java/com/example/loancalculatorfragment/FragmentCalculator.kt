package com.example.loancalculatorfragment

import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SeekBar
import java.lang.NumberFormatException
import kotlinx.android.synthetic.main.fragment_calculator.*
import kotlin.math.pow

class FragmentCalculator : Fragment() {

    // loan amount entered by the user
    private var currentLoanAmount = 0.00
    // interest rate set with the seek bar
    private var currentInterestRate = 0

    // constants used when saving/restoring state
    companion object {
        private const val LOAN_AMOUNT = "LOAN_AMOUNT"
        private const val INTEREST_RATE = "INTEREST_RATE"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_calculator, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // check if the app was just started or is being restored from memory
        if (savedInstanceState == null) {
            // initialize the current loan amount and current interest rate
            currentLoanAmount = 0.00
            currentInterestRate = 5
        }
        else {
            // set the current loan amount and current interest rate to the saved amount
            currentLoanAmount = savedInstanceState.getDouble(LOAN_AMOUNT)
            currentInterestRate = savedInstanceState.getInt(INTEREST_RATE)
        }

        // handles the loanAmountEditText's onTextChangedEvent
        loanAmountEditText.addTextChangedListener(loanAmountEditTextWatcher)
        // handles the seek bar value onChangeEvent
        interestRateSeekBar.setOnSeekBarChangeListener(interestRateSeekBarListener)
    }

    // update the EMI and Total Amount values on the GUI
    private fun updateValues() {
        // calculate the loan amount at 5 years
        val yearFiveEMI = calculateEMI(5)
        val yearFiveTotal = yearFiveEMI * 5.00 * 12.00
        // update the GUI
        yearFiveTotalEditText.setText(String.format("%.02f", yearFiveTotal))
        yearFiveEMIEditText.setText(String.format("%.02f", yearFiveEMI))

        // calculate the loan amount at 10 years
        val yearTenEMI = calculateEMI(10)
        val yearTenTotal = yearTenEMI * 10.00 * 12.00
        // update the GUI
        yearTenTotalEditText.setText(String.format("%.02f", yearTenTotal))
        yearTenEMIEditText.setText(String.format("%.02f", yearTenEMI))

        // calculate the loan amount at 15 years
        val yearFifteenEMI = calculateEMI(15)
        val yearFifteenTotal = yearFifteenEMI * 15.00 * 12.00
        // update the GUI
        yearFifteenTotalEditText.setText(String.format("%.02f", yearFifteenTotal))
        yearFifteenEMIEditText.setText(String.format("%.02f", yearFifteenEMI))

        // calculate the loan amount at 20 years
        val yearTwentyEMI = calculateEMI(20)
        val yearTwentyTotal = yearTwentyEMI * 20.00 * 12.00
        // update the GUI
        yearTwentyTotalEditText.setText(String.format("%.02f", yearTwentyTotal))
        yearTwentyEMIEditText.setText(String.format("%.02f", yearTwentyEMI))

        // calculate the loan amount at 25 years
        val yearTwentyFiveEMI = calculateEMI(25)
        val yearTwentyFiveTotal = yearTwentyFiveEMI * 25.00 * 12.00
        // update the GUI
        yearTwentyFiveTotalEditText.setText(String.format("%.02f", yearTwentyFiveTotal))
        yearTwentyFiveEMIEditText.setText(String.format("%.02f", yearTwentyFiveEMI))

        // calculate the loan amount at 30 years
        val yearThirtyEMI = calculateEMI(30)
        val yearThirtyTotal = yearThirtyEMI * 30.00 * 12.00
        // update the GUI
        yearThirtyTotalEditText.setText(String.format("%.02f", yearThirtyTotal))
        yearThirtyEMIEditText.setText(String.format("%.02f", yearThirtyEMI))
    }

    // calculate the EMI using a given period in years
    private fun calculateEMI(years: Int): Double {
        if (currentInterestRate == 0) {
            return 0.00
        }
        val r = currentInterestRate / 1200.00
        val n = years * 12
        val power = ((1.00 + r).toDouble()).pow(n)
        return (currentLoanAmount * r * power) / (power - 1.00)
    }

    // save the instance of the app to save loan amount and interest rate
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putDouble(LOAN_AMOUNT, currentLoanAmount)
        outState.putInt(INTEREST_RATE, currentInterestRate)
    }

    // called when the user changes the position of the seek bar
    private val interestRateSeekBarListener = object: SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
            // update the current interest rate percent and then update all values
            currentInterestRate = progress
            interestRatePercentTextView.text = currentInterestRate.toString() + "%"
            updateValues()
        }

        override fun onStartTrackingTouch(seekBar: SeekBar?) {
            // ignore, not using
        }

        override fun onStopTrackingTouch(seekBar: SeekBar?) {
            // ignore, not using
        }
    }

    // called when the loan amount text is changed
    private val loanAmountEditTextWatcher = object: TextWatcher {
        override fun beforeTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
            // ignore, not using
        }

        override fun onTextChanged(text: CharSequence?, start: Int, before: Int, count: Int) {
            // convert the loanAmountEditText text into a Double
            try {
                currentLoanAmount = text.toString().toDouble()
            }
            catch (e: NumberFormatException) {
                currentLoanAmount = 0.00 // default if exception occurs
            }

            // update the GUI
            updateValues()
        }

        override fun afterTextChanged(editable: Editable?) {
            // ignore, not using
        }
    }
}