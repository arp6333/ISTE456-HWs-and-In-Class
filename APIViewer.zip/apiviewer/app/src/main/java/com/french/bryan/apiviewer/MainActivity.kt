package com.french.bryan.apiviewer

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.AsyncTask
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import android.text.Html
import android.util.Log
import android.view.View
import androidx.core.content.ContextCompat.getSystemService
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.lang.Exception
import java.lang.IllegalStateException
import java.lang.StringBuilder
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL

class MainActivity : AppCompatActivity() {

    val apiURL = "https://icanhazdadjoke.com"
    var okHttpClient: OkHttpClient = OkHttpClient()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        okHttpBtn.setOnClickListener { loadRandomJoke() }
        coroutinesBtn.setOnClickListener { loadRandomJokeCoroutines() }
        asyncTaskBtn.setOnClickListener { loadRandomJokeAsyncTask() }

    }

    private fun isNetworkConnected(): Boolean {
        val connectivityManager = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val nw = connectivityManager.activeNetwork ?: return false
            val actNw = connectivityManager.getNetworkCapabilities(nw) ?: return false
            return when {
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> true
                actNw.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> true
                else -> false
            }
        }
        else {
            val nwInfo = connectivityManager.activeNetworkInfo ?: return false
            return nwInfo.isConnected
        }
    }

    private fun loadRandomJoke() {
        if (isNetworkConnected()) {
            runOnUiThread {
                progressBar.visibility = View.VISIBLE
            }

            val request: Request = Request.Builder().url(apiURL)
                .addHeader("Accept", "application/json")
                .build()

            okHttpClient.newCall(request).enqueue(object : Callback {
                override fun onFailure(call: Call, e: IOException) {

                }

                override fun onResponse(call: Call, response: Response) {
                    val json = response?.body?.string()
                    val txt = (JSONObject(json).get("joke")).toString()

                    runOnUiThread {
                        progressBar.visibility = View.GONE
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                            joke.text = Html.fromHtml(txt, Html.FROM_HTML_MODE_LEGACY)
                        } else {
                            joke.text = Html.fromHtml(txt)
                        }
                    }
                }
            })
        }
        else {
            AlertDialog.Builder(this)
                .setTitle("No internet connection")
                .setMessage("Please check your internet connection and try again")
                .setPositiveButton(android.R.string.ok) { _,_ -> }
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show()
        }
    }

    private fun loadRandomJokeCoroutines() {
        if (isNetworkConnected()) {
            GlobalScope.launch(Dispatchers.Main) {
                try {
                    // main thread
                    progressBar.visibility = View.VISIBLE
                    var result = ""

                    // off main thread
                    withContext(this.coroutineContext + Dispatchers.IO) {
                        result = fetchJokeBlocking()
                    }

                    // back to main thread - won't process this until withContext finishes but also won't block main thread
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                        joke.text = Html.fromHtml(result, Html.FROM_HTML_MODE_LEGACY)
                    }
                    else {
                        joke.text = Html.fromHtml(result)
                    }
                }
                catch (e: Exception) {
                    // ignore right now
                }
                finally {
                    progressBar.visibility = View.GONE
                }
            }
        }
        else {
            AlertDialog.Builder(this)
                .setTitle("No internet connection")
                .setMessage("Please check your internet connection and try again")
                .setPositiveButton(android.R.string.ok) { _,_ -> }
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show()
        }
    }

    private fun fetchJokeBlocking() : String {
        var urlConnection: HttpURLConnection? = null
        var txt = "Problem with connection"

        try {
            val webServiceURL = URL(apiURL)
            urlConnection = webServiceURL.openConnection() as HttpURLConnection
            urlConnection.setRequestProperty("Accept", "application/json")
            val responseCode = urlConnection.responseCode
            if (responseCode != HttpURLConnection.HTTP_OK) {
                txt = "Problem with request"
            }
            else {
                val bufferedReader = BufferedReader(InputStreamReader(urlConnection.inputStream))
                val stringBuilder = StringBuilder()
                var line: String? = bufferedReader.readLine()
                while (line != null) {
                    stringBuilder.append(line).append("\n")
                    line = bufferedReader.readLine()
                }
                bufferedReader.close()
                txt = (JSONObject(stringBuilder.toString()).get("joke")).toString()
            }
        }
        catch (e: MalformedURLException) {
            Log.v("DAD_JOKE", e.toString())
        }
        catch (e: IOException) {
            Log.v("DAD_JOKE", e.toString())
        }
        catch (e: IllegalStateException) {
            Log.v("DAD_JOKE", e.toString())
        }
        finally {
            urlConnection?.disconnect()
            return txt
        }
    }

    private fun loadRandomJokeAsyncTask() {
        if (isNetworkConnected()) {
            ReadDadJokeTask().execute(apiURL)
        }
        else {
            AlertDialog.Builder(this)
                .setTitle("No internet connection")
                .setMessage("Please check your internet connection and try again")
                .setPositiveButton(android.R.string.ok) { _,_ -> }
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show()
        }
    }

    inner class ReadDadJokeTask(): AsyncTask<String, Void, String>() {
        // runs on main thread, called automatically before doInBackground
        override fun onPreExecute() {
            progressBar.visibility = View.VISIBLE
        }

        // also runs on main thread, called automatically after doInBackground
        override fun onPostExecute(result: String?) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                joke.text = Html.fromHtml(result, Html.FROM_HTML_MODE_LEGACY)
            }
            else {
                joke.text = Html.fromHtml(result)
            }

            progressBar.visibility = View.GONE
        }

        // runs on background thread
        override fun doInBackground(vararg myURL: String?): String {
            return fetchJokeBlocking()
        }
    }

}//MainActivity
