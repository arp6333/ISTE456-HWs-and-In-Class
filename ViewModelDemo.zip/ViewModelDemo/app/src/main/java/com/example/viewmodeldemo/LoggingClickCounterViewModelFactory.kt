package com.example.viewmodeldemo

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import java.lang.IllegalArgumentException

class LoggingClickCounterViewModelFactory(private val loggingInterceptor: ClickLoggingInterceptor): ViewModelProvider.Factory {
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(LoggingClickCounterViewModel::class.java)) {
            return LoggingClickCounterViewModel(loggingInterceptor) as T
        }
        throw IllegalArgumentException("Unknown ViewModel Class")
    }

}