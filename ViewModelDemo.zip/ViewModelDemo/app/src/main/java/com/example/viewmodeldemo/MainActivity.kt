package com.example.viewmodeldemo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    // If we have no parameters, we can use this method
    //private val viewModel: ClickCounterViewModel by lazy {
    //    ViewModelProvider(this).get(ClickCounterViewModel::class.java)
    //}

    // Factory needed if we want to use parameters
    private val viewModel: ClickCounterViewModel by lazy {
        val factory = LoggingClickCounterViewModelFactory(ClickLoggingInterceptor())
        ViewModelProvider(this, factory).get(LoggingClickCounterViewModel::class.java)
    }

    private val timerViewModel: LiveDataViewModel by lazy {
        ViewModelProvider(this).get(LiveDataViewModel::class.java)
    }

    private val LOG_TAG = MainActivity::class.java.simpleName

    private val elapsedTimeObserver = Observer<Long> { newValue ->
        val newText = "$newValue seconds"
        displayTimerValue(newText)
        Log.d(LOG_TAG, "Updating timer")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        subscribeElapsedTimeObserver()

        lifecycle.addObserver(MyObserver())

        displayClickCount(viewModel.getCount())

        increment_button.setOnClickListener {
            //click_count_text.text = (click_count_text.text.toString().toInt() + 1).toString()
            viewModel.setCount(viewModel.getCount() + 1)
            displayClickCount(viewModel.getCount())
        }
    }

    private fun displayClickCount(count: Int) {
        click_count_text.text = count.toString()
    }

    private fun subscribeElapsedTimeObserver() {
        timerViewModel.getElapsedTime().observe(this, elapsedTimeObserver)
    }

    private fun displayTimerValue(value: String) {
        timer_value_text.text = value
    }
}