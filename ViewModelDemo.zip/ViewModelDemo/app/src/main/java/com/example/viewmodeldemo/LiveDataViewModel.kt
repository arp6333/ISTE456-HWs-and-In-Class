package com.example.viewmodeldemo

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import java.util.*

class LiveDataViewModel: ViewModel() {
    private val elapsedTime = MutableLiveData<Long>()
    private val initialTime: Long = SystemClock.elapsedRealtime()

    init {
        val timer = Timer()
        timer.scheduleAtFixedRate(object: TimerTask() {
            override fun run() {
                val newValue = (SystemClock.elapsedRealtime() - initialTime) / 1000

                // setValue can't be called from a background thread
                Handler(Looper.getMainLooper()).post(Runnable {
                    elapsedTime.value = newValue
                })
            }
        }, ONE_SECOND, ONE_SECOND)
    }

    fun getElapsedTime(): LiveData<Long> {
        return elapsedTime
    }

    companion object {
        const val ONE_SECOND: Long = 1000
    }
}