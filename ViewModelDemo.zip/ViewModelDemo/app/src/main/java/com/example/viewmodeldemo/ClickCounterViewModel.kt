package com.example.viewmodeldemo

import androidx.lifecycle.ViewModel

// Classes by default are final (cannot be extended) so we make it open
open class ClickCounterViewModel: ViewModel() {
    private var count = 0

    // Also open so we can override it
    open fun setCount(count: Int) {
        this.count = count
    }

    fun getCount(): Int {
        return count
    }
}