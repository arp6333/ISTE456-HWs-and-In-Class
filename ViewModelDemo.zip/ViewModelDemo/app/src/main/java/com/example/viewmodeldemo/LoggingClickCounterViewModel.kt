package com.example.viewmodeldemo

import android.util.Log

class LoggingClickCounterViewModel(val loggingInterceptor: ClickLoggingInterceptor): ClickCounterViewModel() {
    override fun setCount(count: Int) {
        super.setCount(count)
        loggingInterceptor.intercept(count)
    }
}

class ClickLoggingInterceptor {
    fun intercept(clickCount: Int) {
        Log.d(LOG_TAG, "processed click $clickCount")
    }

    companion object {
        private val LOG_TAG = ClickLoggingInterceptor::class.java.simpleName
    }
}